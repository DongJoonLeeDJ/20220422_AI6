﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSharpStudy01
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //실행 : ctrl + F5

            //cw 누르고 tab 키 두 번
            Console.WriteLine("Hello"); //java의 println과 동일
            Console.Write("Hey"); //java의 print와 동일(출력하고 한 줄 안 띔)

            Console.WriteLine("-----");


            Console.Write("Write"); //한 줄 띄지 않음
            Console.WriteLine("WriteLine"); //ctrl + d 누르면 한 줄 복사&붙여넣기
            Console.WriteLine("WriteLine");
            Console.WriteLine("WriteLine");
            Console.Write("Write");
            Console.WriteLine("Write");


        }
    }
}
