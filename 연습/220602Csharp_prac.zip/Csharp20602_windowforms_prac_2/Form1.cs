﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Csharp20602_windowforms_prac_2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            panelLeft.Height = button4.Height;
            panelLeft.Top = button4.Top;
        }

        private void buttonDashBoard_Click(object sender, EventArgs e)
        {
            panelLeft.Height=buttonDashBoard.Height;
            panelLeft.Top = buttonDashBoard.Top;
        }

        private void buttonSeller_Click(object sender, EventArgs e)
        {
            panelLeft.Height = buttonSeller.Height;
            panelLeft.Top = buttonSeller.Top;
        }

        private void buttonCalender_Click(object sender, EventArgs e)
        {
            panelLeft.Height = buttonCalender.Height;
            panelLeft.Top = buttonCalender.Top;
        }
    }
}
