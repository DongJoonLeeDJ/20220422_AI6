﻿namespace Projectlotto
{
    partial class two
    {
        /// <summary> 
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region 구성 요소 디자이너에서 생성한 코드

        /// <summary> 
        /// 디자이너 지원에 필요한 메서드입니다. 
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마세요.
        /// </summary>
        private void InitializeComponent()
        {
            this.twb6 = new System.Windows.Forms.Label();
            this.onb6 = new System.Windows.Forms.Label();
            this.twb5 = new System.Windows.Forms.Label();
            this.onb5 = new System.Windows.Forms.Label();
            this.twb4 = new System.Windows.Forms.Label();
            this.onb4 = new System.Windows.Forms.Label();
            this.twb3 = new System.Windows.Forms.Label();
            this.onb3 = new System.Windows.Forms.Label();
            this.twb2 = new System.Windows.Forms.Label();
            this.onb2 = new System.Windows.Forms.Label();
            this.twb1 = new System.Windows.Forms.Label();
            this.onb1 = new System.Windows.Forms.Label();
            this.B1 = new System.Windows.Forms.Label();
            this.A1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // twb6
            // 
            this.twb6.AutoSize = true;
            this.twb6.Font = new System.Drawing.Font("경기천년제목V Bold", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.twb6.Location = new System.Drawing.Point(524, 147);
            this.twb6.Name = "twb6";
            this.twb6.Size = new System.Drawing.Size(65, 19);
            this.twb6.TabIndex = 60;
            this.twb6.Text = "B 자동";
            // 
            // onb6
            // 
            this.onb6.AutoSize = true;
            this.onb6.Font = new System.Drawing.Font("경기천년제목V Bold", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.onb6.Location = new System.Drawing.Point(524, 108);
            this.onb6.Name = "onb6";
            this.onb6.Size = new System.Drawing.Size(65, 19);
            this.onb6.TabIndex = 61;
            this.onb6.Text = "A 자동";
            // 
            // twb5
            // 
            this.twb5.AutoSize = true;
            this.twb5.Font = new System.Drawing.Font("경기천년제목V Bold", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.twb5.Location = new System.Drawing.Point(455, 147);
            this.twb5.Name = "twb5";
            this.twb5.Size = new System.Drawing.Size(65, 19);
            this.twb5.TabIndex = 62;
            this.twb5.Text = "B 자동";
            // 
            // onb5
            // 
            this.onb5.AutoSize = true;
            this.onb5.Font = new System.Drawing.Font("경기천년제목V Bold", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.onb5.Location = new System.Drawing.Point(455, 108);
            this.onb5.Name = "onb5";
            this.onb5.Size = new System.Drawing.Size(65, 19);
            this.onb5.TabIndex = 63;
            this.onb5.Text = "A 자동";
            // 
            // twb4
            // 
            this.twb4.AutoSize = true;
            this.twb4.Font = new System.Drawing.Font("경기천년제목V Bold", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.twb4.Location = new System.Drawing.Point(387, 147);
            this.twb4.Name = "twb4";
            this.twb4.Size = new System.Drawing.Size(65, 19);
            this.twb4.TabIndex = 64;
            this.twb4.Text = "B 자동";
            // 
            // onb4
            // 
            this.onb4.AutoSize = true;
            this.onb4.Font = new System.Drawing.Font("경기천년제목V Bold", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.onb4.Location = new System.Drawing.Point(387, 108);
            this.onb4.Name = "onb4";
            this.onb4.Size = new System.Drawing.Size(65, 19);
            this.onb4.TabIndex = 65;
            this.onb4.Text = "A 자동";
            // 
            // twb3
            // 
            this.twb3.AutoSize = true;
            this.twb3.Font = new System.Drawing.Font("경기천년제목V Bold", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.twb3.Location = new System.Drawing.Point(318, 147);
            this.twb3.Name = "twb3";
            this.twb3.Size = new System.Drawing.Size(65, 19);
            this.twb3.TabIndex = 66;
            this.twb3.Text = "B 자동";
            // 
            // onb3
            // 
            this.onb3.AutoSize = true;
            this.onb3.Font = new System.Drawing.Font("경기천년제목V Bold", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.onb3.Location = new System.Drawing.Point(318, 108);
            this.onb3.Name = "onb3";
            this.onb3.Size = new System.Drawing.Size(65, 19);
            this.onb3.TabIndex = 67;
            this.onb3.Text = "A 자동";
            // 
            // twb2
            // 
            this.twb2.AutoSize = true;
            this.twb2.Font = new System.Drawing.Font("경기천년제목V Bold", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.twb2.Location = new System.Drawing.Point(249, 147);
            this.twb2.Name = "twb2";
            this.twb2.Size = new System.Drawing.Size(65, 19);
            this.twb2.TabIndex = 68;
            this.twb2.Text = "B 자동";
            // 
            // onb2
            // 
            this.onb2.AutoSize = true;
            this.onb2.Font = new System.Drawing.Font("경기천년제목V Bold", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.onb2.Location = new System.Drawing.Point(249, 108);
            this.onb2.Name = "onb2";
            this.onb2.Size = new System.Drawing.Size(65, 19);
            this.onb2.TabIndex = 69;
            this.onb2.Text = "A 자동";
            // 
            // twb1
            // 
            this.twb1.AutoSize = true;
            this.twb1.Font = new System.Drawing.Font("경기천년제목V Bold", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.twb1.Location = new System.Drawing.Point(177, 147);
            this.twb1.Name = "twb1";
            this.twb1.Size = new System.Drawing.Size(65, 19);
            this.twb1.TabIndex = 71;
            this.twb1.Text = "B 자동";
            // 
            // onb1
            // 
            this.onb1.AutoSize = true;
            this.onb1.Font = new System.Drawing.Font("경기천년제목V Bold", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.onb1.Location = new System.Drawing.Point(177, 108);
            this.onb1.Name = "onb1";
            this.onb1.Size = new System.Drawing.Size(65, 19);
            this.onb1.TabIndex = 70;
            this.onb1.Text = "A 자동";
            // 
            // B1
            // 
            this.B1.AutoSize = true;
            this.B1.Font = new System.Drawing.Font("경기천년제목V Bold", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.B1.Location = new System.Drawing.Point(96, 147);
            this.B1.Name = "B1";
            this.B1.Size = new System.Drawing.Size(65, 19);
            this.B1.TabIndex = 72;
            this.B1.Text = "B 자동";
            // 
            // A1
            // 
            this.A1.AutoSize = true;
            this.A1.Font = new System.Drawing.Font("경기천년제목V Bold", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.A1.Location = new System.Drawing.Point(96, 108);
            this.A1.Name = "A1";
            this.A1.Size = new System.Drawing.Size(65, 19);
            this.A1.TabIndex = 73;
            this.A1.Text = "A 자동";
            // 
            // two
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.twb6);
            this.Controls.Add(this.onb6);
            this.Controls.Add(this.twb5);
            this.Controls.Add(this.onb5);
            this.Controls.Add(this.twb4);
            this.Controls.Add(this.onb4);
            this.Controls.Add(this.twb3);
            this.Controls.Add(this.onb3);
            this.Controls.Add(this.twb2);
            this.Controls.Add(this.onb2);
            this.Controls.Add(this.twb1);
            this.Controls.Add(this.onb1);
            this.Controls.Add(this.B1);
            this.Controls.Add(this.A1);
            this.Name = "two";
            this.Size = new System.Drawing.Size(684, 274);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label twb6;
        private System.Windows.Forms.Label onb6;
        private System.Windows.Forms.Label twb5;
        private System.Windows.Forms.Label onb5;
        private System.Windows.Forms.Label twb4;
        private System.Windows.Forms.Label onb4;
        private System.Windows.Forms.Label twb3;
        private System.Windows.Forms.Label onb3;
        private System.Windows.Forms.Label twb2;
        private System.Windows.Forms.Label onb2;
        private System.Windows.Forms.Label twb1;
        private System.Windows.Forms.Label onb1;
        private System.Windows.Forms.Label B1;
        private System.Windows.Forms.Label A1;
    }
}
