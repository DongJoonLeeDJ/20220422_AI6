﻿namespace Projectlotto
{
    partial class five
    {
        /// <summary> 
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region 구성 요소 디자이너에서 생성한 코드

        /// <summary> 
        /// 디자이너 지원에 필요한 메서드입니다. 
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마세요.
        /// </summary>
        private void InitializeComponent()
        {
            this.onb6 = new System.Windows.Forms.Label();
            this.onb5 = new System.Windows.Forms.Label();
            this.onb4 = new System.Windows.Forms.Label();
            this.onb3 = new System.Windows.Forms.Label();
            this.onb2 = new System.Windows.Forms.Label();
            this.onb1 = new System.Windows.Forms.Label();
            this.A1 = new System.Windows.Forms.Label();
            this.B1 = new System.Windows.Forms.Label();
            this.twb1 = new System.Windows.Forms.Label();
            this.twb2 = new System.Windows.Forms.Label();
            this.twb3 = new System.Windows.Forms.Label();
            this.twb4 = new System.Windows.Forms.Label();
            this.twb5 = new System.Windows.Forms.Label();
            this.twb6 = new System.Windows.Forms.Label();
            this.C1 = new System.Windows.Forms.Label();
            this.thb1 = new System.Windows.Forms.Label();
            this.thb2 = new System.Windows.Forms.Label();
            this.thb3 = new System.Windows.Forms.Label();
            this.thb4 = new System.Windows.Forms.Label();
            this.thb5 = new System.Windows.Forms.Label();
            this.thb6 = new System.Windows.Forms.Label();
            this.D1 = new System.Windows.Forms.Label();
            this.fob1 = new System.Windows.Forms.Label();
            this.fob2 = new System.Windows.Forms.Label();
            this.fob3 = new System.Windows.Forms.Label();
            this.fob4 = new System.Windows.Forms.Label();
            this.fob5 = new System.Windows.Forms.Label();
            this.fob6 = new System.Windows.Forms.Label();
            this.E1 = new System.Windows.Forms.Label();
            this.fib1 = new System.Windows.Forms.Label();
            this.fib2 = new System.Windows.Forms.Label();
            this.fib3 = new System.Windows.Forms.Label();
            this.fib4 = new System.Windows.Forms.Label();
            this.fib5 = new System.Windows.Forms.Label();
            this.fib6 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // onb6
            // 
            this.onb6.AutoSize = true;
            this.onb6.Font = new System.Drawing.Font("경기천년제목V Bold", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.onb6.Location = new System.Drawing.Point(517, 46);
            this.onb6.Name = "onb6";
            this.onb6.Size = new System.Drawing.Size(65, 19);
            this.onb6.TabIndex = 4;
            this.onb6.Text = "A 자동";
            // 
            // onb5
            // 
            this.onb5.AutoSize = true;
            this.onb5.Font = new System.Drawing.Font("경기천년제목V Bold", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.onb5.Location = new System.Drawing.Point(448, 46);
            this.onb5.Name = "onb5";
            this.onb5.Size = new System.Drawing.Size(65, 19);
            this.onb5.TabIndex = 5;
            this.onb5.Text = "A 자동";
            // 
            // onb4
            // 
            this.onb4.AutoSize = true;
            this.onb4.Font = new System.Drawing.Font("경기천년제목V Bold", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.onb4.Location = new System.Drawing.Point(380, 46);
            this.onb4.Name = "onb4";
            this.onb4.Size = new System.Drawing.Size(65, 19);
            this.onb4.TabIndex = 6;
            this.onb4.Text = "A 자동";
            // 
            // onb3
            // 
            this.onb3.AutoSize = true;
            this.onb3.Font = new System.Drawing.Font("경기천년제목V Bold", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.onb3.Location = new System.Drawing.Point(311, 46);
            this.onb3.Name = "onb3";
            this.onb3.Size = new System.Drawing.Size(65, 19);
            this.onb3.TabIndex = 7;
            this.onb3.Text = "A 자동";
            // 
            // onb2
            // 
            this.onb2.AutoSize = true;
            this.onb2.Font = new System.Drawing.Font("경기천년제목V Bold", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.onb2.Location = new System.Drawing.Point(242, 46);
            this.onb2.Name = "onb2";
            this.onb2.Size = new System.Drawing.Size(65, 19);
            this.onb2.TabIndex = 8;
            this.onb2.Text = "A 자동";
            // 
            // onb1
            // 
            this.onb1.AutoSize = true;
            this.onb1.Font = new System.Drawing.Font("경기천년제목V Bold", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.onb1.Location = new System.Drawing.Point(170, 46);
            this.onb1.Name = "onb1";
            this.onb1.Size = new System.Drawing.Size(65, 19);
            this.onb1.TabIndex = 9;
            this.onb1.Text = "A 자동";
            // 
            // A1
            // 
            this.A1.AutoSize = true;
            this.A1.Font = new System.Drawing.Font("경기천년제목V Bold", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.A1.Location = new System.Drawing.Point(89, 46);
            this.A1.Name = "A1";
            this.A1.Size = new System.Drawing.Size(65, 19);
            this.A1.TabIndex = 10;
            this.A1.Text = "A 자동";
            // 
            // B1
            // 
            this.B1.AutoSize = true;
            this.B1.Font = new System.Drawing.Font("경기천년제목V Bold", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.B1.Location = new System.Drawing.Point(89, 85);
            this.B1.Name = "B1";
            this.B1.Size = new System.Drawing.Size(65, 19);
            this.B1.TabIndex = 10;
            this.B1.Text = "B 자동";
            // 
            // twb1
            // 
            this.twb1.AutoSize = true;
            this.twb1.Font = new System.Drawing.Font("경기천년제목V Bold", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.twb1.Location = new System.Drawing.Point(170, 85);
            this.twb1.Name = "twb1";
            this.twb1.Size = new System.Drawing.Size(65, 19);
            this.twb1.TabIndex = 9;
            this.twb1.Text = "B 자동";
            // 
            // twb2
            // 
            this.twb2.AutoSize = true;
            this.twb2.Font = new System.Drawing.Font("경기천년제목V Bold", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.twb2.Location = new System.Drawing.Point(242, 85);
            this.twb2.Name = "twb2";
            this.twb2.Size = new System.Drawing.Size(65, 19);
            this.twb2.TabIndex = 8;
            this.twb2.Text = "B 자동";
            // 
            // twb3
            // 
            this.twb3.AutoSize = true;
            this.twb3.Font = new System.Drawing.Font("경기천년제목V Bold", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.twb3.Location = new System.Drawing.Point(311, 85);
            this.twb3.Name = "twb3";
            this.twb3.Size = new System.Drawing.Size(65, 19);
            this.twb3.TabIndex = 7;
            this.twb3.Text = "B 자동";
            // 
            // twb4
            // 
            this.twb4.AutoSize = true;
            this.twb4.Font = new System.Drawing.Font("경기천년제목V Bold", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.twb4.Location = new System.Drawing.Point(380, 85);
            this.twb4.Name = "twb4";
            this.twb4.Size = new System.Drawing.Size(65, 19);
            this.twb4.TabIndex = 6;
            this.twb4.Text = "B 자동";
            // 
            // twb5
            // 
            this.twb5.AutoSize = true;
            this.twb5.Font = new System.Drawing.Font("경기천년제목V Bold", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.twb5.Location = new System.Drawing.Point(448, 85);
            this.twb5.Name = "twb5";
            this.twb5.Size = new System.Drawing.Size(65, 19);
            this.twb5.TabIndex = 5;
            this.twb5.Text = "B 자동";
            // 
            // twb6
            // 
            this.twb6.AutoSize = true;
            this.twb6.Font = new System.Drawing.Font("경기천년제목V Bold", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.twb6.Location = new System.Drawing.Point(517, 85);
            this.twb6.Name = "twb6";
            this.twb6.Size = new System.Drawing.Size(65, 19);
            this.twb6.TabIndex = 4;
            this.twb6.Text = "B 자동";
            // 
            // C1
            // 
            this.C1.AutoSize = true;
            this.C1.Font = new System.Drawing.Font("경기천년제목V Bold", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.C1.Location = new System.Drawing.Point(89, 123);
            this.C1.Name = "C1";
            this.C1.Size = new System.Drawing.Size(65, 19);
            this.C1.TabIndex = 10;
            this.C1.Text = "C 자동";
            // 
            // thb1
            // 
            this.thb1.AutoSize = true;
            this.thb1.Font = new System.Drawing.Font("경기천년제목V Bold", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.thb1.Location = new System.Drawing.Point(170, 123);
            this.thb1.Name = "thb1";
            this.thb1.Size = new System.Drawing.Size(65, 19);
            this.thb1.TabIndex = 9;
            this.thb1.Text = "C 자동";
            // 
            // thb2
            // 
            this.thb2.AutoSize = true;
            this.thb2.Font = new System.Drawing.Font("경기천년제목V Bold", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.thb2.Location = new System.Drawing.Point(242, 123);
            this.thb2.Name = "thb2";
            this.thb2.Size = new System.Drawing.Size(65, 19);
            this.thb2.TabIndex = 8;
            this.thb2.Text = "C 자동";
            // 
            // thb3
            // 
            this.thb3.AutoSize = true;
            this.thb3.Font = new System.Drawing.Font("경기천년제목V Bold", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.thb3.Location = new System.Drawing.Point(311, 123);
            this.thb3.Name = "thb3";
            this.thb3.Size = new System.Drawing.Size(65, 19);
            this.thb3.TabIndex = 7;
            this.thb3.Text = "C 자동";
            // 
            // thb4
            // 
            this.thb4.AutoSize = true;
            this.thb4.Font = new System.Drawing.Font("경기천년제목V Bold", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.thb4.Location = new System.Drawing.Point(380, 123);
            this.thb4.Name = "thb4";
            this.thb4.Size = new System.Drawing.Size(65, 19);
            this.thb4.TabIndex = 6;
            this.thb4.Text = "C 자동";
            // 
            // thb5
            // 
            this.thb5.AutoSize = true;
            this.thb5.Font = new System.Drawing.Font("경기천년제목V Bold", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.thb5.Location = new System.Drawing.Point(448, 123);
            this.thb5.Name = "thb5";
            this.thb5.Size = new System.Drawing.Size(65, 19);
            this.thb5.TabIndex = 5;
            this.thb5.Text = "C 자동";
            // 
            // thb6
            // 
            this.thb6.AutoSize = true;
            this.thb6.Font = new System.Drawing.Font("경기천년제목V Bold", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.thb6.Location = new System.Drawing.Point(517, 123);
            this.thb6.Name = "thb6";
            this.thb6.Size = new System.Drawing.Size(65, 19);
            this.thb6.TabIndex = 4;
            this.thb6.Text = "C 자동";
            // 
            // D1
            // 
            this.D1.AutoSize = true;
            this.D1.Font = new System.Drawing.Font("경기천년제목V Bold", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.D1.Location = new System.Drawing.Point(89, 161);
            this.D1.Name = "D1";
            this.D1.Size = new System.Drawing.Size(65, 19);
            this.D1.TabIndex = 10;
            this.D1.Text = "D 자동";
            // 
            // fob1
            // 
            this.fob1.AutoSize = true;
            this.fob1.Font = new System.Drawing.Font("경기천년제목V Bold", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.fob1.Location = new System.Drawing.Point(170, 161);
            this.fob1.Name = "fob1";
            this.fob1.Size = new System.Drawing.Size(65, 19);
            this.fob1.TabIndex = 9;
            this.fob1.Text = "D 자동";
            // 
            // fob2
            // 
            this.fob2.AutoSize = true;
            this.fob2.Font = new System.Drawing.Font("경기천년제목V Bold", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.fob2.Location = new System.Drawing.Point(242, 161);
            this.fob2.Name = "fob2";
            this.fob2.Size = new System.Drawing.Size(65, 19);
            this.fob2.TabIndex = 8;
            this.fob2.Text = "D 자동";
            // 
            // fob3
            // 
            this.fob3.AutoSize = true;
            this.fob3.Font = new System.Drawing.Font("경기천년제목V Bold", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.fob3.Location = new System.Drawing.Point(311, 161);
            this.fob3.Name = "fob3";
            this.fob3.Size = new System.Drawing.Size(65, 19);
            this.fob3.TabIndex = 7;
            this.fob3.Text = "D 자동";
            // 
            // fob4
            // 
            this.fob4.AutoSize = true;
            this.fob4.Font = new System.Drawing.Font("경기천년제목V Bold", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.fob4.Location = new System.Drawing.Point(380, 161);
            this.fob4.Name = "fob4";
            this.fob4.Size = new System.Drawing.Size(65, 19);
            this.fob4.TabIndex = 6;
            this.fob4.Text = "D 자동";
            // 
            // fob5
            // 
            this.fob5.AutoSize = true;
            this.fob5.Font = new System.Drawing.Font("경기천년제목V Bold", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.fob5.Location = new System.Drawing.Point(448, 161);
            this.fob5.Name = "fob5";
            this.fob5.Size = new System.Drawing.Size(65, 19);
            this.fob5.TabIndex = 5;
            this.fob5.Text = "D 자동";
            // 
            // fob6
            // 
            this.fob6.AutoSize = true;
            this.fob6.Font = new System.Drawing.Font("경기천년제목V Bold", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.fob6.Location = new System.Drawing.Point(517, 161);
            this.fob6.Name = "fob6";
            this.fob6.Size = new System.Drawing.Size(65, 19);
            this.fob6.TabIndex = 4;
            this.fob6.Text = "D 자동";
            // 
            // E1
            // 
            this.E1.AutoSize = true;
            this.E1.Font = new System.Drawing.Font("경기천년제목V Bold", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.E1.Location = new System.Drawing.Point(89, 198);
            this.E1.Name = "E1";
            this.E1.Size = new System.Drawing.Size(64, 19);
            this.E1.TabIndex = 10;
            this.E1.Text = "E 자동";
            // 
            // fib1
            // 
            this.fib1.AutoSize = true;
            this.fib1.Font = new System.Drawing.Font("경기천년제목V Bold", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.fib1.Location = new System.Drawing.Point(170, 198);
            this.fib1.Name = "fib1";
            this.fib1.Size = new System.Drawing.Size(64, 19);
            this.fib1.TabIndex = 9;
            this.fib1.Text = "E 자동";
            // 
            // fib2
            // 
            this.fib2.AutoSize = true;
            this.fib2.Font = new System.Drawing.Font("경기천년제목V Bold", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.fib2.Location = new System.Drawing.Point(242, 198);
            this.fib2.Name = "fib2";
            this.fib2.Size = new System.Drawing.Size(64, 19);
            this.fib2.TabIndex = 8;
            this.fib2.Text = "E 자동";
            // 
            // fib3
            // 
            this.fib3.AutoSize = true;
            this.fib3.Font = new System.Drawing.Font("경기천년제목V Bold", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.fib3.Location = new System.Drawing.Point(311, 198);
            this.fib3.Name = "fib3";
            this.fib3.Size = new System.Drawing.Size(64, 19);
            this.fib3.TabIndex = 7;
            this.fib3.Text = "E 자동";
            // 
            // fib4
            // 
            this.fib4.AutoSize = true;
            this.fib4.Font = new System.Drawing.Font("경기천년제목V Bold", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.fib4.Location = new System.Drawing.Point(380, 198);
            this.fib4.Name = "fib4";
            this.fib4.Size = new System.Drawing.Size(64, 19);
            this.fib4.TabIndex = 6;
            this.fib4.Text = "E 자동";
            // 
            // fib5
            // 
            this.fib5.AutoSize = true;
            this.fib5.Font = new System.Drawing.Font("경기천년제목V Bold", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.fib5.Location = new System.Drawing.Point(448, 198);
            this.fib5.Name = "fib5";
            this.fib5.Size = new System.Drawing.Size(64, 19);
            this.fib5.TabIndex = 5;
            this.fib5.Text = "E 자동";
            // 
            // fib6
            // 
            this.fib6.AutoSize = true;
            this.fib6.Font = new System.Drawing.Font("경기천년제목V Bold", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.fib6.Location = new System.Drawing.Point(517, 198);
            this.fib6.Name = "fib6";
            this.fib6.Size = new System.Drawing.Size(64, 19);
            this.fib6.TabIndex = 4;
            this.fib6.Text = "E 자동";
            // 
            // five
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.fib6);
            this.Controls.Add(this.fob6);
            this.Controls.Add(this.fib5);
            this.Controls.Add(this.thb6);
            this.Controls.Add(this.fob5);
            this.Controls.Add(this.twb6);
            this.Controls.Add(this.thb5);
            this.Controls.Add(this.fib4);
            this.Controls.Add(this.onb6);
            this.Controls.Add(this.fob4);
            this.Controls.Add(this.twb5);
            this.Controls.Add(this.thb4);
            this.Controls.Add(this.fib3);
            this.Controls.Add(this.onb5);
            this.Controls.Add(this.fob3);
            this.Controls.Add(this.twb4);
            this.Controls.Add(this.thb3);
            this.Controls.Add(this.fib2);
            this.Controls.Add(this.onb4);
            this.Controls.Add(this.fob2);
            this.Controls.Add(this.twb3);
            this.Controls.Add(this.thb2);
            this.Controls.Add(this.fib1);
            this.Controls.Add(this.onb3);
            this.Controls.Add(this.fob1);
            this.Controls.Add(this.twb2);
            this.Controls.Add(this.thb1);
            this.Controls.Add(this.E1);
            this.Controls.Add(this.onb2);
            this.Controls.Add(this.D1);
            this.Controls.Add(this.twb1);
            this.Controls.Add(this.C1);
            this.Controls.Add(this.onb1);
            this.Controls.Add(this.B1);
            this.Controls.Add(this.A1);
            this.Name = "five";
            this.Size = new System.Drawing.Size(684, 274);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label onb6;
        private System.Windows.Forms.Label onb5;
        private System.Windows.Forms.Label onb4;
        private System.Windows.Forms.Label onb3;
        private System.Windows.Forms.Label onb2;
        private System.Windows.Forms.Label onb1;
        private System.Windows.Forms.Label A1;
        private System.Windows.Forms.Label B1;
        private System.Windows.Forms.Label twb1;
        private System.Windows.Forms.Label twb2;
        private System.Windows.Forms.Label twb3;
        private System.Windows.Forms.Label twb4;
        private System.Windows.Forms.Label twb5;
        private System.Windows.Forms.Label twb6;
        private System.Windows.Forms.Label C1;
        private System.Windows.Forms.Label thb1;
        private System.Windows.Forms.Label thb2;
        private System.Windows.Forms.Label thb3;
        private System.Windows.Forms.Label thb4;
        private System.Windows.Forms.Label thb5;
        private System.Windows.Forms.Label thb6;
        private System.Windows.Forms.Label D1;
        private System.Windows.Forms.Label fob1;
        private System.Windows.Forms.Label fob2;
        private System.Windows.Forms.Label fob3;
        private System.Windows.Forms.Label fob4;
        private System.Windows.Forms.Label fob5;
        private System.Windows.Forms.Label fob6;
        private System.Windows.Forms.Label E1;
        private System.Windows.Forms.Label fib1;
        private System.Windows.Forms.Label fib2;
        private System.Windows.Forms.Label fib3;
        private System.Windows.Forms.Label fib4;
        private System.Windows.Forms.Label fib5;
        private System.Windows.Forms.Label fib6;
    }
}
