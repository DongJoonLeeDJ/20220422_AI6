﻿namespace Projectlotto
{
    partial class UserControl8
    {
        /// <summary> 
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region 구성 요소 디자이너에서 생성한 코드

        /// <summary> 
        /// 디자이너 지원에 필요한 메서드입니다. 
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마세요.
        /// </summary>
        private void InitializeComponent()
        {
            this.onb6 = new System.Windows.Forms.Label();
            this.onb5 = new System.Windows.Forms.Label();
            this.onb4 = new System.Windows.Forms.Label();
            this.onb3 = new System.Windows.Forms.Label();
            this.onb2 = new System.Windows.Forms.Label();
            this.onb1 = new System.Windows.Forms.Label();
            this.A1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // onb6
            // 
            this.onb6.AutoSize = true;
            this.onb6.Font = new System.Drawing.Font("경기천년제목V Bold", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.onb6.Location = new System.Drawing.Point(524, 128);
            this.onb6.Name = "onb6";
            this.onb6.Size = new System.Drawing.Size(65, 19);
            this.onb6.TabIndex = 74;
            this.onb6.Text = "A 자동";
            // 
            // onb5
            // 
            this.onb5.AutoSize = true;
            this.onb5.Font = new System.Drawing.Font("경기천년제목V Bold", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.onb5.Location = new System.Drawing.Point(455, 128);
            this.onb5.Name = "onb5";
            this.onb5.Size = new System.Drawing.Size(65, 19);
            this.onb5.TabIndex = 75;
            this.onb5.Text = "A 자동";
            // 
            // onb4
            // 
            this.onb4.AutoSize = true;
            this.onb4.Font = new System.Drawing.Font("경기천년제목V Bold", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.onb4.Location = new System.Drawing.Point(387, 128);
            this.onb4.Name = "onb4";
            this.onb4.Size = new System.Drawing.Size(65, 19);
            this.onb4.TabIndex = 76;
            this.onb4.Text = "A 자동";
            // 
            // onb3
            // 
            this.onb3.AutoSize = true;
            this.onb3.Font = new System.Drawing.Font("경기천년제목V Bold", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.onb3.Location = new System.Drawing.Point(318, 128);
            this.onb3.Name = "onb3";
            this.onb3.Size = new System.Drawing.Size(65, 19);
            this.onb3.TabIndex = 77;
            this.onb3.Text = "A 자동";
            // 
            // onb2
            // 
            this.onb2.AutoSize = true;
            this.onb2.Font = new System.Drawing.Font("경기천년제목V Bold", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.onb2.Location = new System.Drawing.Point(249, 128);
            this.onb2.Name = "onb2";
            this.onb2.Size = new System.Drawing.Size(65, 19);
            this.onb2.TabIndex = 78;
            this.onb2.Text = "A 자동";
            // 
            // onb1
            // 
            this.onb1.AutoSize = true;
            this.onb1.Font = new System.Drawing.Font("경기천년제목V Bold", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.onb1.Location = new System.Drawing.Point(177, 128);
            this.onb1.Name = "onb1";
            this.onb1.Size = new System.Drawing.Size(65, 19);
            this.onb1.TabIndex = 79;
            this.onb1.Text = "A 자동";
            // 
            // A1
            // 
            this.A1.AutoSize = true;
            this.A1.Font = new System.Drawing.Font("경기천년제목V Bold", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.A1.Location = new System.Drawing.Point(96, 128);
            this.A1.Name = "A1";
            this.A1.Size = new System.Drawing.Size(65, 19);
            this.A1.TabIndex = 80;
            this.A1.Text = "A 자동";
            // 
            // UserControl8
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.onb6);
            this.Controls.Add(this.onb5);
            this.Controls.Add(this.onb4);
            this.Controls.Add(this.onb3);
            this.Controls.Add(this.onb2);
            this.Controls.Add(this.onb1);
            this.Controls.Add(this.A1);
            this.Name = "UserControl8";
            this.Size = new System.Drawing.Size(684, 274);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label onb6;
        private System.Windows.Forms.Label onb5;
        private System.Windows.Forms.Label onb4;
        private System.Windows.Forms.Label onb3;
        private System.Windows.Forms.Label onb2;
        private System.Windows.Forms.Label onb1;
        private System.Windows.Forms.Label A1;
    }
}
