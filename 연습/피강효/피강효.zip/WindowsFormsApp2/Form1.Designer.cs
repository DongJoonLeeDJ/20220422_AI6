﻿namespace WindowsFormsApp2
{
    partial class Form1
    {
        /// <summary>
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 디자이너에서 생성한 코드

        /// <summary>
        /// 디자이너 지원에 필요한 메서드입니다. 
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마세요.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.button5 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.button7 = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.buttonshops = new System.Windows.Forms.Button();
            this.buttoninstargram = new System.Windows.Forms.Button();
            this.buttonfacebook = new System.Windows.Forms.Button();
            this.buttongoogle = new System.Windows.Forms.Button();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.checkBox2 = new System.Windows.Forms.CheckBox();
            this.checkBox3 = new System.Windows.Forms.CheckBox();
            this.checkBox4 = new System.Windows.Forms.CheckBox();
            this.panel4 = new System.Windows.Forms.Panel();
            this.panelleft = new System.Windows.Forms.Panel();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.panel4);
            this.panel1.Controls.Add(this.buttonshops);
            this.panel1.Controls.Add(this.buttoninstargram);
            this.panel1.Controls.Add(this.buttonfacebook);
            this.panel1.Controls.Add(this.buttongoogle);
            this.panel1.Controls.Add(this.panel3);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(200, 465);
            this.panel1.TabIndex = 0;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.Gray;
            this.panel2.Controls.Add(this.checkBox4);
            this.panel2.Controls.Add(this.checkBox3);
            this.panel2.Controls.Add(this.checkBox2);
            this.panel2.Controls.Add(this.checkBox1);
            this.panel2.Controls.Add(this.pictureBox2);
            this.panel2.Controls.Add(this.label3);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel2.Location = new System.Drawing.Point(200, 292);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(600, 173);
            this.panel2.TabIndex = 1;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.panel3.Controls.Add(this.label1);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel3.Location = new System.Drawing.Point(0, 0);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(200, 128);
            this.panel3.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("굴림", 72F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label1.Location = new System.Drawing.Point(47, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(123, 96);
            this.label1.TabIndex = 2;
            this.label1.Text = "m";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label2.ForeColor = System.Drawing.Color.Cyan;
            this.label2.Location = new System.Drawing.Point(225, 100);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(48, 16);
            this.label2.TabIndex = 2;
            this.label2.Text = "totals";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label3.ForeColor = System.Drawing.Color.Cyan;
            this.label3.Location = new System.Drawing.Point(389, 13);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(47, 16);
            this.label3.TabIndex = 4;
            this.label3.Text = "tasks";
            // 
            // button5
            // 
            this.button5.FlatAppearance.BorderSize = 0;
            this.button5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button5.ForeColor = System.Drawing.Color.Cyan;
            this.button5.Location = new System.Drawing.Point(681, 93);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(75, 23);
            this.button5.TabIndex = 4;
            this.button5.Text = "weeks";
            this.button5.UseVisualStyleBackColor = true;
            // 
            // button6
            // 
            this.button6.FlatAppearance.BorderSize = 0;
            this.button6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button6.ForeColor = System.Drawing.Color.Cyan;
            this.button6.Location = new System.Drawing.Point(624, 93);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(75, 23);
            this.button6.TabIndex = 5;
            this.button6.Text = "months";
            this.button6.UseVisualStyleBackColor = true;
            // 
            // button7
            // 
            this.button7.FlatAppearance.BorderSize = 0;
            this.button7.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button7.ForeColor = System.Drawing.Color.Cyan;
            this.button7.Location = new System.Drawing.Point(561, 93);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(75, 23);
            this.button7.TabIndex = 6;
            this.button7.Text = "years";
            this.button7.UseVisualStyleBackColor = true;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::WindowsFormsApp2.Properties.Resources.다운로드;
            this.pictureBox1.Location = new System.Drawing.Point(218, 134);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(561, 152);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 3;
            this.pictureBox1.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::WindowsFormsApp2.Properties.Resources.시간표;
            this.pictureBox2.Location = new System.Drawing.Point(18, 3);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(252, 167);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 5;
            this.pictureBox2.TabStop = false;
            // 
            // buttonshops
            // 
            this.buttonshops.FlatAppearance.BorderSize = 0;
            this.buttonshops.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonshops.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.buttonshops.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.buttonshops.Image = global::WindowsFormsApp2.Properties.Resources.icons8_shopping_cart_32px;
            this.buttonshops.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.buttonshops.Location = new System.Drawing.Point(0, 365);
            this.buttonshops.Name = "buttonshops";
            this.buttonshops.Size = new System.Drawing.Size(200, 88);
            this.buttonshops.TabIndex = 6;
            this.buttonshops.Text = "Shops";
            this.buttonshops.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.buttonshops.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.buttonshops.UseVisualStyleBackColor = true;
            this.buttonshops.Click += new System.EventHandler(this.buttonshops_Click);
            // 
            // buttoninstargram
            // 
            this.buttoninstargram.FlatAppearance.BorderSize = 0;
            this.buttoninstargram.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttoninstargram.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.buttoninstargram.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.buttoninstargram.Image = global::WindowsFormsApp2.Properties.Resources.icons8_instagram_logo_48px;
            this.buttoninstargram.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.buttoninstargram.Location = new System.Drawing.Point(0, 280);
            this.buttoninstargram.Name = "buttoninstargram";
            this.buttoninstargram.Size = new System.Drawing.Size(200, 88);
            this.buttoninstargram.TabIndex = 5;
            this.buttoninstargram.Text = "Instargram";
            this.buttoninstargram.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.buttoninstargram.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.buttoninstargram.UseVisualStyleBackColor = true;
            this.buttoninstargram.Click += new System.EventHandler(this.buttoninstargram_Click);
            // 
            // buttonfacebook
            // 
            this.buttonfacebook.FlatAppearance.BorderSize = 0;
            this.buttonfacebook.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonfacebook.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.buttonfacebook.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.buttonfacebook.Image = global::WindowsFormsApp2.Properties.Resources.icons8_facebook_48px;
            this.buttonfacebook.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.buttonfacebook.Location = new System.Drawing.Point(0, 206);
            this.buttonfacebook.Name = "buttonfacebook";
            this.buttonfacebook.Size = new System.Drawing.Size(200, 88);
            this.buttonfacebook.TabIndex = 4;
            this.buttonfacebook.Text = "Facebook";
            this.buttonfacebook.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.buttonfacebook.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.buttonfacebook.UseVisualStyleBackColor = true;
            this.buttonfacebook.Click += new System.EventHandler(this.buttonfacebook_Click);
            // 
            // buttongoogle
            // 
            this.buttongoogle.FlatAppearance.BorderSize = 0;
            this.buttongoogle.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttongoogle.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.buttongoogle.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.buttongoogle.Image = global::WindowsFormsApp2.Properties.Resources.icons8_google_48px;
            this.buttongoogle.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.buttongoogle.Location = new System.Drawing.Point(0, 125);
            this.buttongoogle.Name = "buttongoogle";
            this.buttongoogle.Size = new System.Drawing.Size(200, 75);
            this.buttongoogle.TabIndex = 3;
            this.buttongoogle.Text = "Google";
            this.buttongoogle.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.buttongoogle.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.buttongoogle.UseVisualStyleBackColor = true;
            this.buttongoogle.Click += new System.EventHandler(this.buttongoogle_Click);
            // 
            // checkBox1
            // 
            this.checkBox1.AutoSize = true;
            this.checkBox1.ForeColor = System.Drawing.Color.Cyan;
            this.checkBox1.Location = new System.Drawing.Point(361, 48);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(95, 16);
            this.checkBox1.TabIndex = 6;
            this.checkBox1.Text = "lorem ipsum";
            this.checkBox1.UseVisualStyleBackColor = true;
            // 
            // checkBox2
            // 
            this.checkBox2.AutoSize = true;
            this.checkBox2.ForeColor = System.Drawing.Color.Cyan;
            this.checkBox2.Location = new System.Drawing.Point(361, 70);
            this.checkBox2.Name = "checkBox2";
            this.checkBox2.Size = new System.Drawing.Size(101, 16);
            this.checkBox2.TabIndex = 7;
            this.checkBox2.Text = "lorem ipsum2";
            this.checkBox2.UseVisualStyleBackColor = true;
            // 
            // checkBox3
            // 
            this.checkBox3.AutoSize = true;
            this.checkBox3.ForeColor = System.Drawing.Color.Cyan;
            this.checkBox3.Location = new System.Drawing.Point(361, 114);
            this.checkBox3.Name = "checkBox3";
            this.checkBox3.Size = new System.Drawing.Size(79, 16);
            this.checkBox3.TabIndex = 8;
            this.checkBox3.Text = "c# design";
            this.checkBox3.UseVisualStyleBackColor = true;
            // 
            // checkBox4
            // 
            this.checkBox4.AutoSize = true;
            this.checkBox4.ForeColor = System.Drawing.Color.Cyan;
            this.checkBox4.Location = new System.Drawing.Point(361, 92);
            this.checkBox4.Name = "checkBox4";
            this.checkBox4.Size = new System.Drawing.Size(37, 16);
            this.checkBox4.TabIndex = 9;
            this.checkBox4.Text = "c#";
            this.checkBox4.UseVisualStyleBackColor = true;
            this.checkBox4.CheckedChanged += new System.EventHandler(this.checkBox4_CheckedChanged);
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.panel4.Location = new System.Drawing.Point(200, 134);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(12, 75);
            this.panel4.TabIndex = 7;
            // 
            // panelleft
            // 
            this.panelleft.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.panelleft.Location = new System.Drawing.Point(201, 134);
            this.panelleft.Name = "panelleft";
            this.panelleft.Size = new System.Drawing.Size(16, 75);
            this.panelleft.TabIndex = 7;
            // 
            // Form1
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.BackColor = System.Drawing.Color.Gray;
            this.ClientSize = new System.Drawing.Size(800, 465);
            this.Controls.Add(this.panelleft);
            this.Controls.Add(this.button7);
            this.Controls.Add(this.button6);
            this.Controls.Add(this.button5);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.panel1.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button buttongoogle;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button buttonshops;
        private System.Windows.Forms.Button buttoninstargram;
        private System.Windows.Forms.Button buttonfacebook;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.CheckBox checkBox1;
        private System.Windows.Forms.CheckBox checkBox4;
        private System.Windows.Forms.CheckBox checkBox3;
        private System.Windows.Forms.CheckBox checkBox2;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Panel panelleft;
    }
}

