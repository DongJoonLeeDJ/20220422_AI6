﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void checkBox4_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void buttongoogle_Click(object sender, EventArgs e)
        {
            panelleft.Height = buttongoogle.Height;
            panelleft.Top = buttongoogle.Top;

        }

        private void buttonfacebook_Click(object sender, EventArgs e)
        {
            panelleft.Height = buttonfacebook.Height;
            panelleft.Top=  buttonfacebook.Top;
        }

        private void buttoninstargram_Click(object sender, EventArgs e)
        {
            panelleft.Height=buttoninstargram.Height;
            panelleft.Top = buttoninstargram.Top;
        }

        private void buttonshops_Click(object sender, EventArgs e)
        {
            panelleft.Height = buttonshops.Height;
            panelleft.Top=buttonshops.Top;
        }
    }
}
