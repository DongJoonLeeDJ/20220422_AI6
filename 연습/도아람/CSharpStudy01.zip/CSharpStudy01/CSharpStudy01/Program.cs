﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSharpStudy01
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //cw 누르고 tab 키 두 번
            Console.WriteLine("Hello"); //java의 println과 동일 (출력하고 한 줄 띄운다)
            Console.Write("Hey"); //java의 print와 동일(출력하고 한 줄 안 띔)
            Console.WriteLine();
            Console.Write("Write");
            Console.WriteLine("WriteLine");
            Console.Write("WriteLine");
            Console.Write("Write");
            Console.WriteLine("Write");

            Console.WriteLine("------------");
            Console.Write("Write");
            Console.WriteLine("WriteLine");
            Console.WriteLine("WriteLine"); //ctrl + d 한 줄 복사&붙여넣기
            Console.Write("Write");
            Console.WriteLine("WriteLine");

        }
    }
}
